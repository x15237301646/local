$(function(){
	 $(".header .top .right img").click(function(){
	 	$(".header .top .right input").css({"opacity":"1"});
	 })
	//喜欢图标
	var $img = $(".body_a_a_a_a").prepend("<img src='img/xinRedh.png' />");
	$(".body_a_a_a_a").children("img:eq(0)").hide();
	$(".body_a_a_a_a img").click(function(){
		$(".body_a_a_a_a").children("img:eq(0)").show();
		$(".body_a_a_a_a").children("img:eq(1)").hide();
		$(".body_a_a_a_a").children("p").children("span").text(parseInt($(".body_a_a_a_a").children("p").children("span").text())+1);
	})
	//分享图标
	var $img = $(".body_a_a_a_b").prepend("<img src='img/shareh_yj1.png' />");
	$(".body_a_a_a_b").children("img:eq(0)").hide();
	$(".body_a_a_a_b img").click(function(){
		$(".body_a_a_a_b").children("img:eq(0)").show();
		$(".body_a_a_a_b").children("img:eq(1)").hide();
	})
	
	//分享
	$(".body_a_a_a_b").click(function(){
		$(".body_a_a_a_c").show();
	})
	
})