$(function(){
	 $(".header .top .right img").click(function(){
	 	$(".header .top .right input").css({"opacity":"1"});
	 })
	//大众试用和体验师专享
	$(".body_a_b li").click(function(){
		var index = $(this).index();
		$(this).addClass("active").siblings().removeClass("active");
		if (index==0) {
			$(".body_b_a").show().siblings().hide();
			$(".body_a_b li a:eq(0)").css({"color":"red"});
			$(".body_a_b li a:eq(1)").css({"color":"black"});
			$(".body_a_c").show();
		} 
		if (index==1) {
//			$(".body_a_b li").children(a.eq(1)).css({"color":"red"});
			$(".body_b_e").show().siblings().hide();
			$(".body_a_b li a:eq(0)").css({"color":"black"});
			$(".body_a_b li a:eq(1)").css({"color":"red"});
			$(".body_a_c").hide();
		} 
	})
	//大众试用
	$(".body_a_c li").click(function(){
		var index1 = $(this).index();
		 
//		$(this).css({"color":"black"}).siblings().css("color":"gainsboro");.siblings().css({"color":"gainsboro"});
	if (index1==0) {
		$(".body_b_a").show().siblings().hide();
		$(".body_a_c li a:eq(0)").css({"color":"black"});
		$(".body_a_c li a:eq(1)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(2)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(3)").css({"color":"gainsboro"});
	}
	if (index1==1) {
		$(".body_b_b").show().siblings().hide();
		$(".body_a_c li a:eq(1)").css({"color":"black"});
		$(".body_a_c li a:eq(0)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(2)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(3)").css({"color":"gainsboro"});
	}
	if (index1==2) {
		$(".body_b_c").show().siblings().hide();
		$(".body_a_c li a:eq(2)").css({"color":"black"});
		$(".body_a_c li a:eq(0)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(1)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(3)").css({"color":"gainsboro"});
	}
	if (index1==3) {
		$(".body_b_e").show().siblings().hide();
		$(".body_a_c li a:eq(3)").css({"color":"black"});
		$(".body_a_c li a:eq(0)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(1)").css({"color":"gainsboro"});
		$(".body_a_c li a:eq(2)").css({"color":"gainsboro"});
	}
	})
	//体验师专享
//	$(".body_a_b ul li:eq(1)").click(function(){
//		$(".body_b_e").show().siblings().hide();
//	})
	
	
	$(".body_b li").click(function(){
		window.open("试用详情.html");
	})
})