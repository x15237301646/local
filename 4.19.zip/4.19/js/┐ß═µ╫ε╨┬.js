$(function(){
	 $(".header .top .right img").click(function(){
	 	$(".header .top .right input").css({"opacity":"1"});
	 })
	$(".body_b li").click(function(){
		var index = $(this).index();
		$(this).addClass("active").siblings().removeClass("active");
		if (index==0) {
			$(".body_b_all_a").show().siblings().hide();
//			$(".body_b_all_b").hide();
//			$(".body_b_all_c").hide();
		} 
		if (index==1) {
//			$(".body_b_all_a").hide();
			$(".body_b_all_b").show().siblings().hide();
//			$(".body_b_all_c").hide();
		} 
		if (index==2) {
//			$(".body_b_all_a").hide();
//			$(".body_b_all_b").hide();
			$(".body_b_all_c").show().siblings().hide();	} 
		
	})
})
