$(function(){
	 $(".header .top .right img").click(function(){
	 	$(".header .top .right input").css({"opacity":"1"});
	 })
	
	$(".body_b_b li").click(function(){
		var index = $(this).index();
		$(this).addClass("active").siblings().removeClass("active");
		if (index==0) {
			$(".body_bo_l_left").show();
			$(".body_bo_l_left_a").hide();
		}
		if (index==1) {
			$(".body_bo_l_left_a").show();
			$(".body_bo_l_left").hide();
		}
	})
})