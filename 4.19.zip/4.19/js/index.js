$(function(){
	 $(".header .top .right img").click(function(){
	 	$(".header .top .right input").css({"opacity":"1"});
	 })
	
})
