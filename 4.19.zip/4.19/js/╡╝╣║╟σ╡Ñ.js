$(function(){
	 $(".header .top .right img").click(function(){
	 	$(".header .top .right input").css({"opacity":"1"});
	 })
	$(".body_bo li").click(function(){
		var index = $(this).index();
		$(this).addClass("active").siblings().removeClass("active");
		if (index==0) {
			$(".body_bod").show();
			$(".body_body").hide();
		} 
		if (index==1) {
			$(".body_body").show();
			$(".body_bod").hide();
		} 
	})
	$(".body_bod_b_c").click(function(){
		window.open("导购详情.html");
	})
	
	$(".body_body_b_c").click(function(){
		window.open("导购详情.html");
	})
})